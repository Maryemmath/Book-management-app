﻿using BookManagmentApplication.DTOs;
using BookManagmentApplication.Services;
using Microsoft.AspNetCore.Mvc;

namespace BookManagementAPI.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BooksController(BookService bookService) : ControllerBase
{
    [HttpGet("[action]")]
    public ActionResult<List<BookDTO>> GetBooks([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 10)
    {
        try
        {
            var bookTitles = bookService.GetBooks(pageNumber, pageSize);
            return Ok(bookTitles);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
    }

    [HttpGet("[action]")]
    public ActionResult<BookDTO> GetBookByTitle([FromQuery] string title)
    {
        try
        {
            var book = bookService.GetBookByTitle(title);

            if (book == null)
            {
                return NotFound("Book not found.");
            }

            return Ok(book);
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
    }

    [HttpPost("[action]")]
    public ActionResult AddBook([FromBody] BookDetailsDTO bookDetails)
    {
        try
        {
            bookService.AddBook(bookDetails);
            return Ok();
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(ex.Message);
        }
    }

    [HttpPost("[action]")]
    public ActionResult AddBooksBulk([FromBody] List<BookDetailsDTO> books)
    {
        try
        {
            bookService.AddBooksBulk(books);
            return Ok();
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(ex.Message);
        }
    }

    [HttpPut("[action]")]
    public ActionResult UpdateBook([FromQuery] string title, [FromBody] BookDetailsDTO bookNewDetails)
    {
        try
        {
            bookService.UpdateBook(title, bookNewDetails);
            return Ok();
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(ex.Message);
        }
    }

    [HttpDelete("[action]")]
    public ActionResult DeleteBook([FromQuery] string title)
    {
        try
        {
            bookService.DeleteBook(title);
            return Ok();
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(ex.Message);
        }
    }

    [HttpDelete("[action]")]
    public async Task<IActionResult> SoftDeleteBooksBulk([FromBody] List<string> bookTitles)
    {
        try
        {
            bookService.DeleteBooksBulk(bookTitles);
            return Ok();
        }
        catch (ArgumentException ex)
        {
            return BadRequest(ex.Message);
        }
        catch (InvalidOperationException ex)
        {
            return Conflict(ex.Message);
        }
    }
}
