﻿using BookManagmentApplication.RepositoryContracts;
using BookManagmentApplication.Services;
using BookManagmentInfrastructure;
using BookManagmentInfrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;

namespace BookManagementAPI
{
    public static class DependencyInjection
    {
        internal static void AddServices(this IServiceCollection services, string dbConnectionString)
        {
            services.AddControllers();
            services.AddEndpointsApiExplorer();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "Book Management API",
                    Version = "v1",
                    Description = "API for managing books with CRUD operations"
                });
            });

            services.AddDbContext<BooksDbContext>(options =>
                options.UseSqlServer(dbConnectionString));

            services.AddDbContext<BooksDbContext>();
            services.AddScoped<BookService>();
            services.AddScoped<IBookRepository, BookRepository>();
        }
    }
}