﻿using BookManagmentApplication.Helpers;
using BookManagmentDomain.Models;

namespace BookManagmentApplication.DTOs
{
    public class BookDTO
    {
        public string Title { get; set; } = null!;
        public int PublicationYear { get; set; }
        public string AuthorName { get; set; } = null!;
        public int ViewsCount { get; set; }
        public double PopularityScore { get; set; }

        public static BookDTO BuildBookDTO(Book book)
        {
            return new BookDTO
            {
                Title = book.Title,
                PublicationYear = book.PublicationYear,
                AuthorName = book.AuthorName,
                ViewsCount = book.ViewsCount,
                PopularityScore = Calculator.CalculatePopularityScore(book.ViewsCount, book.PublicationYear),
            };
        }
    }
}