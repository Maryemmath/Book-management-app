﻿namespace BookManagmentApplication.DTOs;

public record BookDetailsDTO(string Title, int PublicationYear, string AuthorName);