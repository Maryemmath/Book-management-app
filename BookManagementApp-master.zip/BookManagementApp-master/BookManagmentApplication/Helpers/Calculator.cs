﻿using BookManagmentDomain.Models;

namespace BookManagmentApplication.Helpers
{
    public static class Calculator
    {
        public static double CalculatePopularityScore(int viewsCount, int publicationYear)
        {
            return viewsCount * 0.5 + (DateTime.Now.Year - publicationYear) * 2;
        }
    }
}
