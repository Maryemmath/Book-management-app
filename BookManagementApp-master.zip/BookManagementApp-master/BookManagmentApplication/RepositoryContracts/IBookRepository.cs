﻿using BookManagmentApplication.DTOs;
using BookManagmentDomain.Models;

namespace BookManagmentApplication.RepositoryContracts;

public interface IBookRepository
{
    void AddBook(BookDetailsDTO bookDetails);
    void AddBooksBulk(List<BookDetailsDTO> books);
    void DeleteBook(string title);
    void DeleteBooksBulk(List<string> bookTitles);
    public Book? GetBookByTitle(string title);
    public List<Book> GetBooks(int pageNumber, int pageSize);
    void UpdateBook(string title, BookDetailsDTO bookNewDetails);
}
