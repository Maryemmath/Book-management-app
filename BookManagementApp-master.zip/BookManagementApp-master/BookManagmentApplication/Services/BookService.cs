﻿using BookManagmentApplication.DTOs;
using BookManagmentApplication.RepositoryContracts;

namespace BookManagmentApplication.Services;

public class BookService(IBookRepository bookRepository)
{
    public List<string> GetBooks(int pageNumber, int pageSize)
    {
        if (pageNumber <= 0 || pageSize <= 0)
        {
            throw new ArgumentException("Page number or size should not be less then 0");
        }

        var books = bookRepository.GetBooks(pageNumber, pageSize);

        var ui =  books.Select(x => x.Title).ToList();
        return ui;
    }

    public BookDTO? GetBookByTitle(string title)
    {
        if (string.IsNullOrEmpty(title))
        {
            throw new ArgumentException("title cannot be null or empty");
        }

        var book = bookRepository.GetBookByTitle(title);

        if (book == null)
        {
            return null;
        }

        return BookDTO.BuildBookDTO(book);
    }

    public void AddBook(BookDetailsDTO bookDetails)
    {
        if (!AreBookDetailsValid(bookDetails))
        {
            throw new ArgumentException("Invalid book details");
        }

        bookRepository.AddBook(bookDetails);
    }



    public void AddBooksBulk(List<BookDetailsDTO> books)
    {
        if (books.Any(x => !AreBookDetailsValid(x)))
        {
            throw new ArgumentException("All book details must be valid");
        }

        bookRepository.AddBooksBulk(books);
    }

    private static bool AreBookDetailsValid(BookDetailsDTO bookDetails)
    {
        return !string.IsNullOrEmpty(bookDetails.Title)
                    && !string.IsNullOrEmpty(bookDetails.AuthorName)
                    && bookDetails.PublicationYear <= DateTime.Now.Year;
    }

    public void UpdateBook(string title, BookDetailsDTO bookNewDetails)
    {
        if (AreBookDetailsValid(bookNewDetails))
        {
            throw new ArgumentException("Invalid book details");
        }

        bookRepository.UpdateBook(title, bookNewDetails);
    }

    public void DeleteBook(string title)
    {
        if (string.IsNullOrEmpty(title))
        {
            throw new ArgumentNullException("Title cannot be null or empty");
        }

        bookRepository.DeleteBook(title);
    }

    public void DeleteBooksBulk(List<string> bookTitles)
    {
        if (bookTitles.Any(string.IsNullOrEmpty))
        {
            throw new ArgumentNullException("All titles must be valid");
        }

        bookRepository.DeleteBooksBulk(bookTitles);
    }
}