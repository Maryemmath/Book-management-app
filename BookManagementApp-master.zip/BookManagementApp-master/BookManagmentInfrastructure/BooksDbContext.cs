﻿using BookManagmentDomain.Models;
using Microsoft.EntityFrameworkCore;

namespace BookManagmentInfrastructure
{
    public class BooksDbContext : DbContext
    {
        public BooksDbContext() : base() { }
        public BooksDbContext(DbContextOptions<BooksDbContext> options) : base(options) { }

        public DbSet<Book> Books => Set<Book>();
    }
}