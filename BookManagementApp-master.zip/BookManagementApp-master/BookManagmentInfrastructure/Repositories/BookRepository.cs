﻿using BookManagmentApplication.DTOs;
using BookManagmentApplication.Helpers;
using BookManagmentApplication.RepositoryContracts;
using BookManagmentDomain.Models;

namespace BookManagmentInfrastructure.Repositories;

public class BookRepository(BooksDbContext dbContext) : IBookRepository
{
    public void AddBook(BookDetailsDTO bookDetails)
    {
        var alreadyExists = dbContext.Books.FirstOrDefault(x => x.Title == bookDetails.Title) is not null;

        if (alreadyExists)
        {
            throw new InvalidOperationException("Book already exists");
        }

        var newBook = new Book
        {
            PublicationYear = bookDetails.PublicationYear,
            AuthorName = bookDetails.AuthorName,
            Title = bookDetails.Title,
            IsDeleted = false,
            ViewsCount = 0,
        };

        dbContext.Books.Add(newBook);
        dbContext.SaveChanges();
    }

    public void AddBooksBulk(List<BookDetailsDTO> books)
    {
        foreach (var bookDetails in books)
        {
            var alreadyExists = dbContext.Books.FirstOrDefault(x => x.Title == bookDetails.Title) is not null;

            if (alreadyExists)
            {
                throw new InvalidOperationException("Book already exists");
            }
        }

        var booksToAdd = books.Select(x => new Book
        {
            PublicationYear = x.PublicationYear,
            AuthorName = x.AuthorName,
            Title = x.Title,
            IsDeleted = false,
            ViewsCount = 0,
        });

        dbContext.Books.AddRange(booksToAdd);
        dbContext.SaveChanges();
    }

    public void DeleteBook(string title)
    {
        var existingBook = dbContext.Books.FirstOrDefault(x => x.Title == title && x.IsDeleted)
            ?? throw new InvalidOperationException("The book you are trying to delete does not exist or is already deleted");

        existingBook.IsDeleted = true;
        dbContext.SaveChanges();
    }

    public void DeleteBooksBulk(List<string> bookTitles)
    {
        var books = dbContext.Books.Where(x => bookTitles.Contains(x.Title)).ToList();
        books.ForEach(x => x.IsDeleted = true);
        dbContext.SaveChanges();
    }

    public Book? GetBookByTitle(string title)
    {
        var book = dbContext.Books.FirstOrDefault(x => x.Title == title && !x.IsDeleted);

        if (book is not null)
        {
            book.ViewsCount++;
            dbContext.SaveChanges();
        }

        return book;
    }

    public List<Book> GetBooks(int pageNumber, int pageSize)
    {
        return [.. dbContext.Books
                 .Where(b => !b.IsDeleted)
                 .OrderByDescending(b => b.ViewsCount * 0.5 + (DateTime.Now.Year - b.PublicationYear) * 2)
                 .Skip((pageNumber - 1) * pageSize)
                 .Take(pageSize)];
    }

    public void UpdateBook(string title, BookDetailsDTO bookNewDetails)
    {
        var existingBook = dbContext.Books.FirstOrDefault(x => x.Title == title && x.IsDeleted) 
            ?? throw new InvalidOperationException("The book you are trying to update does not exist or is deleted");

        existingBook.Title = bookNewDetails.Title;
        existingBook.PublicationYear = bookNewDetails.PublicationYear;
        existingBook.AuthorName = bookNewDetails.AuthorName;

        dbContext.SaveChanges();
    }
}